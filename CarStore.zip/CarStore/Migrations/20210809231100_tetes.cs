﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CarStore.Migrations
{
    public partial class tetes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
